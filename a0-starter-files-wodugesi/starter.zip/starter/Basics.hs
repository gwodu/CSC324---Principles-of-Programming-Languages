module Basics where

{-------------------- Basic FP --------------------}
power5 :: Int -> Int
power5 n = error "TODO"

ageDiscount :: Int -> Float -> Float
ageDiscount age basePrice = error "TODO"

squareTheDiff :: Int -> Int -> Int
squareTheDiff x y = error "TODO"
